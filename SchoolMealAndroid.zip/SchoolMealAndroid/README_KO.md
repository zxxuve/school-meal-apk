# 우리 학교 급식표 Android 프로젝트

이 프로젝트는 급식표 웹 화면을 Android WebView 안에서 실행하는 APK 프로젝트입니다.

## 태블릿만으로 APK 만들기 (GitHub Actions 사용)

### 1. GitHub 저장소 만들기
1. 태블릿 크롬에서 https://github.com/new 을 엽니다.
2. 저장소 이름을 `school-meal-apk`로 입력하고 `Public` 또는 `Private`를 선택해 만듭니다.
3. 이 압축 파일 자체를 저장소에 업로드합니다. 파일명은 `SchoolMealAndroid.zip`으로 해도 됩니다.

### 2. 빌드 워크플로 만들기
저장소에서 `Add file` → `Create new file`을 누르고 파일 이름 칸에 아래 경로를 정확히 입력합니다.
`.github/workflows/build-apk.yml`

파일 내용은 ZIP 안의 `build-apk.yml.txt` 파일에 있는 내용을 전부 복사해 붙여넣고 `Commit changes`를 누릅니다.

### 3. 빌드 실행
1. 저장소의 `Actions` 탭을 엽니다.
2. `Build School Meal APK` 워크플로를 선택합니다.
3. `Run workflow` → 초록색 `Run workflow`를 누릅니다.
4. 작업이 끝나고 초록색 체크 표시가 나오면 해당 실행 페이지 맨 아래 `Artifacts`에서 `school-meal-debug-apk`를 다운로드합니다.
5. 다운로드한 artifact ZIP을 태블릿에서 압축 풀고 `app-debug.apk`를 설치합니다.

## 참고
- GitHub Actions 사용량/제한은 계정 유형과 저장소 공개 설정에 따라 달라질 수 있습니다.
- APK는 디버그 빌드입니다. 개인 기기에서 테스트하기 위한 파일이며 Play Store 배포용 서명 APK가 아닙니다.
- 급식 조회는 외부 `kschoolinfo.com` API에 의존합니다. 해당 API의 가용성이나 응답 형식이 바뀌면 급식 데이터가 표시되지 않을 수 있습니다.
- 앱은 인터넷 권한을 사용합니다. 급식 메뉴 조회에는 인터넷 연결이 필요합니다.
